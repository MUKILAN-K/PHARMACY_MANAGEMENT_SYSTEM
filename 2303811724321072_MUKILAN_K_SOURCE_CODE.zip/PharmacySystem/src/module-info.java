/**
 * 
 */
/**
 * 
 */

module pharmacy.system {
    requires java.desktop;
}
