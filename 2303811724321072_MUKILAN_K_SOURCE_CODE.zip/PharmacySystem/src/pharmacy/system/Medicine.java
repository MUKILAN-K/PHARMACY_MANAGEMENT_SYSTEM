package pharmacy.system;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Medicine {
    private int id;
    private String name;
    private int quantity;
    private Date expiryDate;
    private double price;
    private static final int LOW_STOCK_THRESHOLD = 5;
    private static final int EXPIRY_THRESHOLD_DAYS = 30;
    public Medicine(int id, String name, int quantity, Date expiryDate, double price) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.expiryDate = expiryDate;
        this.price = price;
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public int getQuantity() {
        return quantity;
    }
    public Date getExpiryDate() {
        return expiryDate;
    }
    public double getPrice() {
        return price;
    }
    public boolean isLowStock() {
        return this.quantity <= LOW_STOCK_THRESHOLD;
    }
    public boolean isNearExpiry() {
        long millisInDay = 1000 * 60 * 60 * 24;
        long difference = (expiryDate.getTime() - new Date().getTime()) / millisInDay;
        return difference <= EXPIRY_THRESHOLD_DAYS;
    }
    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return "Medicine ID: " + id + ", Name: " + name + ", Quantity: " + quantity + ", Expiry Date: " + dateFormat.format(expiryDate) + ", Price: $" + price;
    }
}
