package pharmacy.system;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.*;
public class PharmacySystemAWT extends Frame {
    private Inventory inventory;
    private List<Prescription> prescriptions;
    private TextArea displayArea;
    public PharmacySystemAWT() {
        this.inventory = new Inventory();
        this.prescriptions = new ArrayList<>();
        init();
        prepareGUI();
    }
    private void prepareGUI() {
        setTitle("Pharmacy Management System");
        setSize(600, 400);
        setLayout(new BorderLayout());
        Label titleLabel = new Label("Pharmacy Management System", Label.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setBackground(Color.DARK_GRAY);
        titleLabel.setForeground(Color.WHITE);
        add(titleLabel, BorderLayout.NORTH);
        displayArea = new TextArea("\n\n\tWelcome to Pharmacy Management System.\n\tPlease select an option from the right panel to proceed.");
        displayArea.setFont(new Font("Serif", Font.BOLD, 20)); 
        displayArea.setEditable(false);
        displayArea.setBackground(Color.LIGHT_GRAY);
        displayArea.setForeground(Color.DARK_GRAY);
        add(displayArea, BorderLayout.CENTER);
        Panel buttonPanel = new Panel();
        buttonPanel.setLayout(new GridLayout(6, 1, 10, 10));
        Button addMedicineButton = createButton("Add Medicine", Color.ORANGE);
        Button viewInventoryButton = createButton("View Inventory", Color.CYAN);
        Button addPrescriptionButton = createButton("Add Prescription", Color.MAGENTA);
        Button viewPrescriptionsButton = createButton("View Prescriptions", Color.GREEN);
        Button generateBillButton = createButton("Generate Bill", Color.YELLOW);
        Button checkAlertsButton = createButton("Check Stock/Expiry Alerts", Color.PINK);
        buttonPanel.add(addMedicineButton);
        buttonPanel.add(viewInventoryButton);
        buttonPanel.add(addPrescriptionButton);
        buttonPanel.add(viewPrescriptionsButton);
        buttonPanel.add(generateBillButton);
        buttonPanel.add(checkAlertsButton);

        add(buttonPanel, BorderLayout.EAST);
        Panel exitPanel = new Panel();
        Button exitButton = new Button("Exit");
        exitButton.setFont(new Font("Arial", Font.BOLD, 16));
        exitButton.setBackground(Color.RED);
        exitButton.setForeground(Color.WHITE);

        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayArea.setText("\n\n\tWelcome to Pharmacy Management System.\n\tPlease select an option from the right panel to proceed.");
            }
        });
        exitPanel.add(exitButton);
        add(exitPanel, BorderLayout.SOUTH);
        addMedicineButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addMedicine();
            }
        });
        viewInventoryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewInventory();
            }
        });
        addPrescriptionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addPrescription();
            }
        });
        viewPrescriptionsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewPrescriptions();
            }
        });
        generateBillButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                generateBill();
            }
        });
        checkAlertsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                checkAlerts();
            }
        });
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent) {
                System.exit(0);
            }
        });
        setVisible(true);
    }
    private Button createButton(String label, Color color) {
        Button button = new Button(label);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(color);
        button.setForeground(Color.BLACK);
        return button;
    }
    private void init() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            inventory.addMedicine(new Medicine(1, "Paracetamol", 5, dateFormat.parse("2024-12-21"), 10.0));
            inventory.addMedicine(new Medicine(2, "Ibuprofen", 3, dateFormat.parse("2025-01-10"), 15.0));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void addMedicine() {
        TextField idField = new TextField();
        TextField nameField = new TextField();
        TextField quantityField = new TextField();
        TextField priceField = new TextField();
        TextField expiryDateField = new TextField();

        Object[] message = {
            "Medicine ID:", idField,
            "Medicine Name:", nameField,
            "Quantity:", quantityField,
            "Price:", priceField,
            "Expiry Date (yyyy-MM-dd):", expiryDateField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add Medicine", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                int quantity = Integer.parseInt(quantityField.getText());
                double price = Double.parseDouble(priceField.getText());
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date expiryDate = dateFormat.parse(expiryDateField.getText());

                Medicine medicine = new Medicine(id, name, quantity, expiryDate, price);
                inventory.addMedicine(medicine);
                displayArea.setText("Medicine added successfully:\n" + medicine);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void addPrescription() {
        TextField prescriptionIdField = new TextField();
        TextField patientIdField = new TextField();
        TextField doctorIdField = new TextField();
        TextField numMedicinesField = new TextField();

        Object[] message = {
            "Prescription ID:", prescriptionIdField,
            "Patient ID:", patientIdField,
            "Doctor ID:", doctorIdField,
            "Number of Medicines:", numMedicinesField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Add Prescription", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int prescriptionId = Integer.parseInt(prescriptionIdField.getText());
                int patientId = Integer.parseInt(patientIdField.getText());
                int doctorId = Integer.parseInt(doctorIdField.getText());
                int numMedicines = Integer.parseInt(numMedicinesField.getText());

                List<Medicine> medicines = new ArrayList<>();
                for (int i = 0; i < numMedicines; i++) {
                    TextField medicineIdField = new TextField();
                    Object[] medicineMessage = {
                        "Medicine ID " + (i+1) + ":", medicineIdField
                    };
                    int medicineOption = JOptionPane.showConfirmDialog(this, medicineMessage, "Enter Medicine ID", JOptionPane.OK_CANCEL_OPTION);
                    if (medicineOption == JOptionPane.OK_OPTION) {
                        int medicineId = Integer.parseInt(medicineIdField.getText());
                        Medicine medicine = inventory.findMedicineById(medicineId);
                        if (medicine != null) {
                            medicines.add(medicine);
                        } else {
                            JOptionPane.showMessageDialog(this, "Medicine not found. Skipping.", "Warning", JOptionPane.WARNING_MESSAGE);
                        }
                    }
                }

                Date date = new Date();
                Prescription prescription = new Prescription(prescriptionId, patientId, doctorId, date, medicines);
                prescriptions.add(prescription);
                displayArea.setText("Prescription added successfully:\n" + prescription);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void viewInventory() {
        StringBuilder sb = new StringBuilder();
        sb.append("Current Inventory:\n");
        for (Medicine medicine : inventory.getMedicines()) {
            sb.append(medicine).append("\n");
        }
        displayArea.setText(sb.toString());
    }
    private void viewPrescriptions() {
        StringBuilder sb = new StringBuilder();
        sb.append("Prescriptions:\n");
        for (Prescription prescription : prescriptions) {
            sb.append(prescription).append("\n");
        }
        displayArea.setText(sb.toString());
    }
    private void generateBill() {
        TextField prescriptionIdField = new TextField();

        Object[] message = {
            "Prescription ID:", prescriptionIdField
        };
        int option = JOptionPane.showConfirmDialog(this, message, "Generate Bill", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int prescriptionId = Integer.parseInt(prescriptionIdField.getText());
                for (Prescription prescription : prescriptions) {
                    if (prescription.getId() == prescriptionId) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Bill for Prescription ID: ").append(prescriptionId).append("\n");
                        sb.append(prescription);
                        displayArea.setText(sb.toString());
                        return; }}
                JOptionPane.showMessageDialog(this, "Prescription not found.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);}}}
    private void checkAlerts() {
        StringBuilder sb = new StringBuilder();
        sb.append("Stock and Expiry Alerts:\n");
        for (Medicine medicine : inventory.getMedicines()) {
            if (medicine.getQuantity() < 5) {
                sb.append("Low stock alert: ").append(medicine).append("\n");
            }
            if (medicine.getExpiryDate().before(new Date())) {
                sb.append("Expired: ").append(medicine).append("\n");} }
        displayArea.setText(sb.toString()); }
    public static void main(String[] args) {
        new PharmacySystemAWT();
    }
}
