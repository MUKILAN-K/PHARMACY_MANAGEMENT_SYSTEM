package pharmacy.system;

import java.util.Date;
import java.util.List;

public class Prescription {

    private int id;
    private int patientId;
    private int doctorId;
    private Date date;
    private List<Medicine> medicines;

    public Prescription(int id, int patientId, int doctorId, Date date, List<Medicine> medicines) {
        this.id = id;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
        this.medicines = medicines;
    }

    public int getId() {
        return id;
    }

    public double calculateTotalCost() {
        double totalCost = 0;
        for (Medicine medicine : medicines) {
            totalCost += medicine.getPrice();
        }
        return totalCost;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Prescription ID: ").append(id)
          .append(", Patient ID: ").append(patientId)
          .append(", Doctor ID: ").append(doctorId)
          .append("\nDate: ").append(date)
          .append("\nMedicines:\n");
        for (Medicine medicine : medicines) {
            sb.append(medicine).append("\n");
        }
        sb.append("Total Cost: $").append(calculateTotalCost());
        return sb.toString();
    }
}
