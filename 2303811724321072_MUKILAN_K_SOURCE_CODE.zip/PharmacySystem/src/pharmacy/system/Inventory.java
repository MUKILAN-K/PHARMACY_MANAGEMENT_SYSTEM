package pharmacy.system;

import java.util.ArrayList;
import java.util.List;

public class Inventory {

    private List<Medicine> medicines;

    public Inventory() {
        this.medicines = new ArrayList<>();
    }

    public void addMedicine(Medicine medicine) {
        medicines.add(medicine);
    }

    public List<Medicine> getMedicines() {
        return medicines;
    }

    public Medicine findMedicineById(int id) {
        for (Medicine medicine : medicines) {
            if (medicine.getId() == id) {
                return medicine;
            }
        }
        return null;
    }

    public void checkLowStockAndExpiry() {
        System.out.println("\n** Stock Alerts **");
        for (Medicine medicine : medicines) {
            if (medicine.isLowStock()) {
                System.out.println("Low stock alert for Medicine: " + medicine.getName() + " (ID: " + medicine.getId() + ")");
            }
            if (medicine.isNearExpiry()) {
                System.out.println("Expiry alert for Medicine: " + medicine.getName() + " (ID: " + medicine.getId() + ")");
            }
        }
    }
}
